var _main_8cpp =
[
    [ "pedirSiRepetir", "_main_8cpp.html#a3beb010f45f97c3bb6f0132c4487f009", null ],
    [ "pedirTamanio", "_main_8cpp.html#a3850ffb072bd92bcd52ecf23d2562a98", null ],
    [ "pedirValor", "_main_8cpp.html#af04796db10787812a2067e24fa59a968", null ]
];