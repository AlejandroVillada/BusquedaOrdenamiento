var class_gestor_arreglo =
[
    [ "GestorArreglo", "class_gestor_arreglo.html#ad38fd16db338c5d3de579fae12277870", null ],
    [ "~GestorArreglo", "class_gestor_arreglo.html#ae3fb8b4cbe24150b4ab785ed3940ce07", null ],
    [ "busquedaBinaria", "class_gestor_arreglo.html#af9b7e167e7cdc6cd7a91c2f1864dcbc6", null ],
    [ "busquedaSecuencial", "class_gestor_arreglo.html#a01a38c323b26f41affcb9659ee8e0929", null ],
    [ "compararTiempos", "class_gestor_arreglo.html#aba9b785f6c6d42016e65229a69bf710d", null ],
    [ "configurar", "class_gestor_arreglo.html#a80547101b614d22fead9f432c2b086c8", null ],
    [ "desordenar", "class_gestor_arreglo.html#a2198c45e1cd2a9db7cd8514249b6cbc0", null ],
    [ "getEstaOrdenado", "class_gestor_arreglo.html#a1cc1187bd7bc626466948d061f9ea8aa", null ],
    [ "getN", "class_gestor_arreglo.html#aee91ab7511d6c03c431c591569640800", null ],
    [ "mostrar", "class_gestor_arreglo.html#a36873ca5b4265f4e0d8d145c6a46ed56", null ],
    [ "ordenarBurbuja", "class_gestor_arreglo.html#a96537d60d09c738fa5d9ef58384ad2cf", null ],
    [ "ordenarInsercion", "class_gestor_arreglo.html#a8bb7363a228a762a792c927f04957d1a", null ],
    [ "ordenarMergeSort", "class_gestor_arreglo.html#a22105a3139a6cea5e532e2f2676bdb68", null ],
    [ "ordenarQuickSort", "class_gestor_arreglo.html#aea8ac2958b190a1daead1692eab67a39", null ],
    [ "ordenarSeleccion", "class_gestor_arreglo.html#a62c6b6b7c155774b803617a217b8579e", null ]
];