var searchData=
[
  ['comparartiempos_0',['compararTiempos',['../class_gestor_arreglo.html#aba9b785f6c6d42016e65229a69bf710d',1,'GestorArreglo']]],
  ['configurar_1',['configurar',['../class_gestor_arreglo.html#a80547101b614d22fead9f432c2b086c8',1,'GestorArreglo']]]
];
