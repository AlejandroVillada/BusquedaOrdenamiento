var searchData=
[
  ['pedirmostrarproceso_0',['pedirMostrarProceso',['../view_8h.html#a007e83a2f23f40a824c3973ecfbf06dd',1,'view.cpp']]],
  ['pedirsirepetir_1',['pedirSiRepetir',['../view_8h.html#a3beb010f45f97c3bb6f0132c4487f009',1,'pedirSiRepetir():&#160;view.cpp'],['../_main_8cpp.html#a3beb010f45f97c3bb6f0132c4487f009',1,'pedirSiRepetir():&#160;Main.cpp']]],
  ['pedirtamanio_2',['pedirTamanio',['../view_8h.html#a3850ffb072bd92bcd52ecf23d2562a98',1,'pedirTamanio():&#160;view.cpp'],['../_main_8cpp.html#a3850ffb072bd92bcd52ecf23d2562a98',1,'pedirTamanio():&#160;Main.cpp']]],
  ['pedirvalor_3',['pedirValor',['../view_8h.html#af04796db10787812a2067e24fa59a968',1,'pedirValor():&#160;view.cpp'],['../_main_8cpp.html#af04796db10787812a2067e24fa59a968',1,'pedirValor():&#160;Main.cpp']]]
];
