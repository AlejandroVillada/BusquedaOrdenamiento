var search_8h =
[
    [ "busquedaBinaria", "search_8h.html#adcc1bc85b9363ce92f06219f04ac8f64", null ],
    [ "busquedaSecuencial", "search_8h.html#a75e6fd1d78c3b2e70ff37a3b5b3cc7c4", null ]
];