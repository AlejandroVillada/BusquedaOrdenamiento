var sort_8h =
[
    [ "mergeSort", "sort_8h.html#abdf58439a993e7265e3c58303dc7a18d", null ],
    [ "ordenarBurbuja", "sort_8h.html#a04c00918d91cc9a1da4273101c8ea2f1", null ],
    [ "ordenarInsercion", "sort_8h.html#a87b829fd659471c3fd9864b0a605eb00", null ],
    [ "ordenarSeleccion", "sort_8h.html#a8a1ad56bbb967ea346d4667f6d3fe94f", null ],
    [ "quickSort", "sort_8h.html#a4886199729fb0652c13a77be092f2afc", null ]
];