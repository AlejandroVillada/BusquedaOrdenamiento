var view_8h =
[
    [ "mostrarArreglo", "view_8h.html#afd6df2510401f6e3589246083fb2b474", null ],
    [ "mostrarMenu", "view_8h.html#a104d3a852326f8dd86a3b9b5fee17c7d", null ],
    [ "mostrarMenuOrdenamiento", "view_8h.html#a43d509d542aa7504b3529820da872262", null ],
    [ "pedirMostrarProceso", "view_8h.html#a007e83a2f23f40a824c3973ecfbf06dd", null ],
    [ "pedirSiRepetir", "view_8h.html#a3beb010f45f97c3bb6f0132c4487f009", null ],
    [ "pedirTamanio", "view_8h.html#a3850ffb072bd92bcd52ecf23d2562a98", null ],
    [ "pedirValor", "view_8h.html#af04796db10787812a2067e24fa59a968", null ]
];